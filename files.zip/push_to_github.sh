#!/bin/bash
# ╔══════════════════════════════════════════════════╗
# ║   BITSPARKS → GitHub Auto-Push Script           ║
# ║   Ready to run — no edits needed!               ║
# ╚══════════════════════════════════════════════════╝

GITHUB_USERNAME="ravivelu869-afk"
REPO_NAME="bitsparks-student-app"
FILE="bitsparks_v6.html"
COMMIT_MSG="🚀 BITSPARKS v6 — Live internships + upgraded Focus Games fonts"

# ── Validate file exists ──────────────────────────────
if [ ! -f "$FILE" ]; then
  echo ""
  echo "❌ ERROR: $FILE not found in this folder."
  echo "   Make sure bitsparks_v6.html is in the same folder as this script."
  exit 1
fi

echo ""
echo "════════════════════════════════════════════════"
echo "  🚀 BITSPARKS → GitHub Push"
echo "  👤 User : $GITHUB_USERNAME"
echo "  📦 Repo : $REPO_NAME"
echo "  📄 File : $FILE"
echo "════════════════════════════════════════════════"
echo ""

# ── STEP 1: Create repo on GitHub ────────────────────
echo "📡 Creating GitHub repo '$REPO_NAME'..."
echo "   Enter your GitHub Personal Access Token (PAT) when prompted for password."
echo ""

curl -s \
  -X POST \
  -u "$GITHUB_USERNAME" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/user/repos \
  -d "{
    \"name\": \"$REPO_NAME\",
    \"description\": \"BITSPARKS — AI-Powered Student Productivity & Well-being Platform\",
    \"private\": false,
    \"auto_init\": false
  }"

echo ""
echo "✅ Repo created (or already exists)."
echo ""

# ── STEP 2: Git init ─────────────────────────────────
echo "📁 Initialising local git repository..."
git init

echo "📄 Staging $FILE..."
git add "$FILE"

echo "💬 Creating commit..."
git commit -m "$COMMIT_MSG"

# ── STEP 3: Set remote and push ──────────────────────
echo "🔗 Linking to GitHub..."
git remote remove origin 2>/dev/null
git remote add origin "https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"

echo "☁️  Pushing to GitHub..."
echo "   When asked for password, enter your GitHub PAT (not your login password)."
git branch -M main
git push -u origin main

echo ""
echo "════════════════════════════════════════════════"
echo "  ✅ SUCCESS! BITSPARKS is live on GitHub:"
echo ""
echo "  🔗 https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo ""
echo "  🌐 FREE live website — enable GitHub Pages:"
echo "  1. Open the link above"
echo "  2. Settings → Pages"
echo "  3. Source: Deploy from branch → main → / (root) → Save"
echo "  4. Live URL:"
echo "     https://$GITHUB_USERNAME.github.io/$REPO_NAME/"
echo "════════════════════════════════════════════════"
echo ""
